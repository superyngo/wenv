# Spec Compliance Review — Task 6

- Spec: `/Volumes/Home/Users/wen/repos/wenv/docs/superpowers/specs/2026-05-22-multi-layer-tree-and-config-fallback-design.md`
- Stage: `task 6`

## Scope Guard
ONLY task 6 (Release Workflow + README/CHANGELOG). Tasks 1-5 done.

## Task body

## Task 6: Release Workflow + README/CHANGELOG

**Files:**
- Modify: `.github/workflows/release.yml`
- Modify: `README.md`
- Modify: `CHANGELOG.md`

### Release workflow

- [ ] **Step 6.1: Read the current workflow archive section**

Run: `sed -n '188,215p' .github/workflows/release.yml`

- [ ] **Step 6.2: Replace archive steps to bundle Resources/**

In `.github/workflows/release.yml`, replace the existing two steps "Create tarball (Linux and macOS)" and "Upload artifacts (Windows)" with the staged version below. The "Upload artifacts (Linux and macOS)" step stays but now uploads from the staged path.

```yaml
      - name: Stage artifacts
        shell: bash
        run: |
          STAGE="${{ matrix.asset_name }}-staged"
          mkdir -p "$STAGE/Resources"
          if [[ "${{ matrix.os }}" == "windows-latest" ]]; then
            cp "target/${{ matrix.target }}/release/${{ matrix.artifact_name }}" "$STAGE/"
          else
            cp "target/${{ matrix.target }}/release/${{ matrix.artifact_name }}" "$STAGE/"
          fi
          cp Resources/config.toml "$STAGE/Resources/config.toml"
          echo "STAGE=$STAGE" >> "$GITHUB_ENV"

      - name: Create tarball (Linux and macOS)
        if: matrix.os != 'windows-latest'
        run: |
          tar czf "${{ matrix.asset_name }}.tar.gz" -C "$STAGE" .
          # alternative: tar czf "${{ matrix.asset_name }}.tar.gz" "$STAGE"
          # keep the simpler layout above

      - name: Create zip (Windows)
        if: matrix.os == 'windows-latest'
        shell: pwsh
        run: |
          Compress-Archive -Path "$env:STAGE/*" -DestinationPath "${{ matrix.asset_name }}.zip"

      - name: Upload artifacts (Linux and macOS)
        if: matrix.os != 'windows-latest'
        uses: actions/upload-artifact@v4
        with:
          name: ${{ matrix.asset_name }}
          path: ${{ matrix.asset_name }}.tar.gz

      - name: Upload artifacts (Windows)
        if: matrix.os == 'windows-latest'
        uses: actions/upload-artifact@v4
        with:
          name: ${{ matrix.asset_name }}
          path: ${{ matrix.asset_name }}.zip
```

Also update the "Prepare release files" step in the `release` job (around `release.yml:236`):

```yaml
      - name: Prepare release files
        run: |
          mkdir -p release_files
          # Tarballs from Linux/macOS builds
          find artifacts -type f -name "*.tar.gz" -exec cp {} release_files/ \;
          # Zips from Windows builds
          find artifacts -type f -name "*.zip" -exec cp {} release_files/ \;
```

(Remove the bespoke "Handle Windows exe files by renaming with platform suffix" block — Windows now ships a zip.)

- [ ] **Step 6.3: Verify YAML syntactically**

Run: `python3 -c "import yaml; yaml.safe_load(open('.github/workflows/release.yml'))"`
Expected: no output (valid YAML).

### README

- [ ] **Step 6.4: Add Development + tarball-layout sections to README**

Append to `README.md`:

```markdown
## Configuration

wenv searches for `config.toml` in an OS-conditional fallback chain and creates a default at the first writable location if none exist. On Linux/macOS the chain is:

1. `$WENV_CONFIG_DIR/config.toml` (when set, for development)
2. `<binary_dir>/Resources/config.toml` (bundled with release tarballs)
3. `$HOME/.wenget/apps/wenv/Resources/config.toml`
4. `$HOME/.local/bin/Resources/config.toml`
5. `/opt/wenget/apps/wenv/Resources/config.toml`
6. `/usr/local/bin/config/config.toml`

Run `wenv config` to open the currently-resolved file in `$EDITOR`.

If the resolved config sits on a read-only filesystem and you make changes in the TUI, wenv writes to the next writable fallback and prints a notice; subsequent runs find the new copy.

See `docs/adr/0001-config-resolution-strategy.md` for the rationale.

## Release tarball layout

Each release tarball unpacks to:

```
wenv-vX.Y.Z-<target>/
├── wenv (or wenv.exe)
└── Resources/
    └── config.toml
```

## Development

To run a development build against an isolated config, set `WENV_CONFIG_DIR`:

```bash
WENV_CONFIG_DIR=$(pwd)/Resources cargo run
```

This prepends the in-repo `Resources/config.toml` to the fallback chain so `cargo run` never touches your installed config.
```

### CHANGELOG

- [ ] **Step 6.5: Add Unreleased entry**

Prepend to `CHANGELOG.md` (after any existing top heading):

```markdown
## Unreleased

### Breaking changes
- `-c, --config` flag removed. Use `wenv config` subcommand instead.
- Config moved from `~/.config/wenv/config.toml` to an OS-conditional fallback chain (see README "Configuration"). No automatic migration; existing files are silently shadowed if a higher-priority fallback exists.
- TUI startup default: all groups and files start collapsed; press `9` to expand all or `0` to collapse all.

### Added
- Three-layer TUI tree: group → file → entry. Globs (`~/.zshrc.d/*`), directory paths, and variables that resolve to directories produce a group.
- `wenv config` subcommand opens the active config in `$EDITOR`.
- `WENV_CONFIG_DIR` env var (development override).
- Release tarballs bundle `Resources/config.toml` next to the binary.
- Sibling `cache.toml` for PowerShell `$PROFILE` resolution (lazy invalidation).
- Variable-bearing paths display as `<resolved> (<original-pattern>)`.

### Fixed
- (None — feature release.)
```

- [ ] **Step 6.6: Commit**

```bash
git add .github/workflows/release.yml README.md CHANGELOG.md
git commit -m "feat(release): bundle Resources/config.toml; docs for v0.17

- release.yml stages each platform binary into wenv-vX.Y.Z-<target>/
  with Resources/config.toml sibling; Windows now ships zip.
- README adds Configuration, Tarball layout, Development sections.
- CHANGELOG records three breaking changes for v0.17.

Spec §7, §9."
```

---

## Done Criteria (run from repo root)

- [ ] `cargo test` — all green
- [ ] `cargo clippy --all-targets -- -D warnings` — clean (or document any remaining warnings inline)
- [ ] `cargo fmt --check` — clean
- [ ] Manual smoke (macOS shell session):
  - `cargo run` → TUI starts fully collapsed; `9` expands all, `0` collapses all.
  - Add a glob to config (`a` in TUI, e.g. `~/.zshrc.d/*`) and verify a Group header appears with the matched files.
  - Pwsh: with `$PROFILE` in config, the file label shows `<resolved> ($PROFILE)`.
  - `wenv config` opens the config in `$EDITOR`; change `language`, save, re-run, observe new language.
  - `d` on a Group → confirms, removes pattern, files vanish.
  - `m` on a Group → status hint "Move is not supported on groups".
  - `m` on a file inside a Group → status hint about alphabetical ordering.
- [ ] CHANGELOG `Unreleased` lists three breaking changes
- [ ] README "Configuration" / "Development" / "Tarball layout" sections present
- [ ] `Resources/config.toml` committed at repo root
- [ ] `docs/adr/0001-config-resolution-strategy.md` committed (already done during grilling)

## Files touched
- .github/workflows/release.yml
- README.md
- CHANGELOG.md

## Severity
`blocker` | `major` | `minor`

## Round Discipline
(Round 1 — focused). Grep before findings.

## Output

```yaml
---
status: PASS | ISSUES_FOUND
issues: []
---
```
