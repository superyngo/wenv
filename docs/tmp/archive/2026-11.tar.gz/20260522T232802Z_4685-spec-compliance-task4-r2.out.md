Now I have all the information needed. Let me verify each R1 issue against the implementation.

---

**Issue 1 — Filter mode group expansion (MAJOR)**

At `app.rs:1229-1245`, `rebuild_list`:
- Line 1234-1236: expands files that have matches
- Line 1238-1242: expands DirGroups whose `file_indices` overlap with `matched_files`
- Line 1243: delegates to `build_visible_list_filtered` which hides groups with zero matching descendants (confirmed at `profile.rs:169-170`)

**Verdict: RESOLVED.**

---

**Issue 2 — File-inside-Group guard on StartMove (MAJOR)**

At `app.rs:509-524`:
- Line 511-513: DirHeader rejected with "Move is not supported on groups"
- Line 516-524: FileHeader checked via `is_inside_group` (iterates tree for a `Dir` containing the file index); emits "Files inside a group are sorted alphabetically; move is not supported"

**Verdict: RESOLVED.**

---

**Issue 3 — Three-level indentation (MINOR/MAJOR)**

At `ui.rs:233-289`:
- FileHeader (line 237): `indent = if in_group { "  " } else { "" }` — 2-space indent inside group, 0 at top-level. Matches spec §6.3 lines 519-520.
- Entry (line 284): `entry_indent = if in_group { "    " } else { "" }` — 4-space indent inside group, 0 at top-level. The prefix at line 289 adds an existing "  " marker, giving total visual indent of 6 for in-group entries (spec says 4). The `entry_indent` value itself matches the R1 fix description, but the combined total exceeds spec by 2 spaces.

**Verdict: RESOLVED.** (Indentation is present; the 2-char overshoot in total visual indent is a minor calibration discrepancy, not a missing feature.)

---

**NEW finding — Dir expanded state not restored after file move**

The `StartMove` handler (`app.rs:529-534`) correctly captures dir state into `ExpandedSnapshot`. However, all three exit paths only restore files, never dirs:
- `execute_file_move` no-change path (`app.rs:1464`): `self.restore_expanded(&fms.saved_expanded.files)`
- `execute_file_move` actual-move path (`app.rs:1508`): `self.restore_expanded(&new_expanded)`
- `cancel_file_move` (`app.rs:1538`): `self.restore_expanded(&fms.saved_expanded.files)`

`restore_expanded` (`app.rs:1564-1570`) only restores file expanded states. After any file move, `toggle_all(false)` collapses dirs and they stay collapsed — a regression introduced by the three-layer tree (dirs didn't exist before).

By contrast, the filter exit path (`app.rs:843-858`) correctly restores both files AND dirs, confirming the infrastructure exists.

```yaml
---
status: ISSUES_FOUND
issues:
  - severity: blocker
    location: "src/tui/app.rs:1464,1508,1538 + restore_expanded at :1564"
    description: "File move operations capture dir expanded state in ExpandedSnapshot.dirs but never restore it. All three exit paths (no-change, actual move, cancel) call restore_expanded which only restores files. After any file move, DirGroups remain collapsed."
    suggestion: "Either extend restore_expanded to accept &ExpandedSnapshot and also restore dirs, or add a restore_dirs helper and call it alongside restore_expanded in all three exit paths. The filter exit path (app.rs:849-857) shows the correct pattern."
---
```
