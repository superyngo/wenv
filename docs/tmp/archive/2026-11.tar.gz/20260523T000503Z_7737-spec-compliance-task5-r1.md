# Spec Compliance Review — Task 5

- Spec: `/Volumes/Home/Users/wen/repos/wenv/docs/superpowers/specs/2026-05-22-multi-layer-tree-and-config-fallback-design.md`
- Stage: `task 5`

## Scope Guard
ONLY task 5 (CLI `wenv config` subcommand). Tasks 1-4 done; task 6 later.

## Other tasks
- Tasks 1-4: completed
- Task 6: Release Workflow + README/CHANGELOG

## Task body

## Task 5: CLI `wenv config` Subcommand

**Files:**
- Modify: `src/cli/args.rs`
- Modify: `src/main.rs`

- [ ] **Step 5.1: Write the args module**

Replace `src/cli/args.rs` content with:

```rust
//! CLI argument definitions

use clap::{Parser, Subcommand, ValueEnum};

#[derive(Parser)]
#[command(name = "wenv")]
#[command(about = "Shell configuration file manager")]
#[command(version, author)]
pub struct Cli {
    /// Specify shell type
    #[arg(short, long, global = true)]
    pub shell: Option<ShellArg>,

    /// Open source file in $EDITOR (same as "wenv .")
    #[arg(long)]
    pub source: bool,

    /// "." to open editor
    #[arg(value_name = "COMMAND")]
    pub command: Option<String>,

    #[command(subcommand)]
    pub subcommand: Option<SubCmd>,
}

#[derive(Subcommand)]
pub enum SubCmd {
    /// Open wenv config file in $EDITOR
    Config,
}

#[derive(Clone, Copy, ValueEnum)]
pub enum ShellArg {
    Bash,
    Zsh,
    Pwsh,
}

impl From<ShellArg> for crate::model::ShellType {
    fn from(arg: ShellArg) -> Self {
        match arg {
            ShellArg::Bash => crate::model::ShellType::Bash,
            ShellArg::Zsh => crate::model::ShellType::Zsh,
            ShellArg::Pwsh => crate::model::ShellType::PowerShell,
        }
    }
}
```

- [ ] **Step 5.2: Wire `wenv config` in main.rs**

In `src/main.rs`, after `let cli = Cli::parse();` (before the shell type detection), add:

```rust
if matches!(cli.subcommand, Some(wenv::cli::args::SubCmd::Config)) {
    let shell_type = wenv::utils::shell_detect::get_shell_type(
        cli.shell.map(Into::into), None);
    let cfg = wenv::model::Config::resolve_or_create(shell_type.config_key())?;
    let editor = std::env::var("EDITOR").unwrap_or_else(|_| {
        if cfg!(windows) { "notepad".into() } else { "vi".into() }
    });
    std::process::Command::new(&editor).arg(&cfg.source_path).status()?;
    return Ok(());
}
```

- [ ] **Step 5.3: Build and smoke-test help output**

Run: `cargo build --bin wenv`
Expected: clean.

Run: `cargo run -- --help`
Expected output includes a `Commands:` section listing `config`. No `-c` flag.

Run: `cargo run -- config --help`
Expected: clap-formatted help for `wenv config` (the bare subcommand has no extra args).

- [ ] **Step 5.4: Commit**

```bash
git add src/cli/args.rs src/main.rs
git commit -m "feat(cli): replace -c/--config flag with 'wenv config' subcommand

Breaking: 'wenv -c' / 'wenv --config' no longer accepted.
'wenv config' opens the currently-resolved config in \$EDITOR
(or notepad/vi default), matching legacy behavior.

Spec §5."
```

---


## Files touched
- src/cli/args.rs
- src/main.rs

## Severity
`blocker` | `major` | `minor`

## Round Discipline
(Round 1 — focused). Grep before findings.

## Output

```yaml
---
status: PASS | ISSUES_FOUND
issues: []
---
```
