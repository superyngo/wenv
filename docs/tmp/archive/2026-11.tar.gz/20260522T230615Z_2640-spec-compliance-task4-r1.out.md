Review complete. Here are my findings:

```yaml
---
status: ISSUES_FOUND
issues:
  - severity: major
    location: "src/tui/app.rs:1197-1217"
    description: "Filter mode does not expand DirGroups with matching descendants. `rebuild_list()` expands matched files (lines 1202-1204) but never sets `g.expanded = true` for groups containing those files. Since DirGroup defaults to `expanded: false` (profile.rs:329), `build_visible_list_filtered` at profile.rs:172 will skip all children under matching groups. Result: in filter mode, group headers appear but no matching files/entries underneath are visible."
    suggestion: "Add group expansion between lines 1204 and 1215: `for n in &mut self.profile.tree { if let TreeNode::Dir(g) = n { g.expanded = g.file_indices.iter().any(|fi| matched_files.contains(fi)); } }`"

  - severity: major
    location: "src/tui/app.rs:514-539"
    description: "Missing File-inside-Group guard on `m` (StartMove) for FileHeader. When cursor is on a FileHeader inside a DirGroup, the handler enters file-move mode without checking group membership. The spec requires rejecting with status message 'Files inside a group are sorted alphabetically; move is not supported'."
    suggestion: "After line 514 (`if let Some(ListItem::FileHeader(fi)) = ...`), add: `let is_inside_group = self.profile.tree.iter().any(|n| matches!(n, TreeNode::Dir(g) if g.file_indices.contains(&fi))); if is_inside_group { self.message = Some(\"Files inside a group are sorted alphabetically; move is not supported\".into()); return Ok(EditorRequest::None); }`"

  - severity: minor
    location: "src/tui/ui.rs:233-274"
    description: "FileHeader and Entry rendering use flat indentation regardless of group membership. The spec requires three-level indentation: DirHeader at 0, FileHeader inside group at 2 spaces, Entry inside group at 4 spaces. Current code renders all FileHeaders with same indent (no prefix) and all Entries with same '  ' prefix."
    suggestion: "Add `inside_group` check (iterate tree for DirGroups containing the file index) and prepend '  ' for FileHeader / '    ' for Entry when inside a group."
---
```

**Summary:** The DirHeader key dispatch (`d`, `e`, `m` on DirHeader, Enter toggle), `reload_profile()`, `ExpandedSnapshot`, `build_visible_list_filtered`, and `a` prompt all match the spec. Three gaps found: (1) filter mode doesn't auto-expand groups with matching files, making those files invisible; (2) no guard preventing file-move on FileHeaders inside groups; (3) flat indentation instead of three-level.
