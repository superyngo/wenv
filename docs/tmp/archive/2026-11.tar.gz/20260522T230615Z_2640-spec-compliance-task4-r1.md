# Spec Compliance Review — Task 4

- Spec: `/Volumes/Home/Users/wen/repos/wenv/docs/superpowers/specs/2026-05-22-multi-layer-tree-and-config-fallback-design.md`
- Stage: `task 4`

## Scope Guard
ONLY task 4 (TUI Keys and Rendering). Tasks 1-3 done; 5-6 later.

## Other tasks
- Task 1, 2, 3: completed
- Task 5: CLI `wenv config` subcommand
- Task 6: Release workflow

## Task body

## Task 4: TUI Keys and Rendering

**Files:**
- Modify: `src/tui/app.rs` (DirHeader events, targeted reload, filter, saved_expanded)
- Modify: `src/tui/list.rs`, `src/tui/ui.rs` (three-layer rendering)
- Modify: `src/tui/state.rs` (extend saved_expanded)
- Create: `tests/targeted_reload.rs`

### Targeted reload tests first

- [ ] **Step 4.1: Write failing test for targeted reload**

Create `tests/targeted_reload.rs`:

```rust
use std::fs;
use tempfile::tempdir;
use wenv::model::profile::{load_shell_profile, TreeNode};
use wenv::model::{Config, FilesConfig, ShellType};

fn make_cfg(td: &tempfile::TempDir, paths: Vec<String>) -> Config {
    let mut c = Config::default();
    c.source_path = td.path().join("config.toml");
    c.files.insert("zsh".into(), FilesConfig { paths });
    c
}

#[test]
fn loading_and_reloading_keeps_indices_stable() {
    let td = tempdir().unwrap();
    fs::write(td.path().join("a.sh"), "alias a=1\n").unwrap();
    fs::write(td.path().join("b.sh"), "alias b=2\n").unwrap();
    let cfg = make_cfg(&td, vec![
        td.path().join("a.sh").to_string_lossy().to_string(),
        td.path().join("b.sh").to_string_lossy().to_string(),
    ]);
    let prof = load_shell_profile(&cfg, ShellType::Zsh).unwrap();
    assert_eq!(prof.files.len(), 2);
    // After removing the second pattern, only a.sh remains
    let cfg2 = make_cfg(&td, vec![
        td.path().join("a.sh").to_string_lossy().to_string(),
    ]);
    let prof2 = load_shell_profile(&cfg2, ShellType::Zsh).unwrap();
    assert_eq!(prof2.files.len(), 1);
    assert_eq!(prof2.tree.len(), 1);
    assert!(matches!(prof2.tree[0], TreeNode::File(0)));
}
```

(Targeted-patch logic itself lives in `app.rs` and is harder to unit-test in isolation; the integration test confirms `load_shell_profile` is deterministic after pattern removal — the app uses this same function via the patch helper.)

- [ ] **Step 4.2: Run — should pass already (load_shell_profile already implemented)**

Run: `cargo test --test targeted_reload`
Expected: PASS.

### Extend `src/tui/state.rs`

- [ ] **Step 4.3: Read state.rs and extend saved_expanded**

Run: `cat src/tui/state.rs`

Find any struct field named `saved_expanded` (probably `Vec<bool>` over files). Replace with:

```rust
/// Snapshot of expanded state across both layers, captured before filter
/// activation or file-move mode, restored on exit.
#[derive(Default, Clone)]
pub struct ExpandedSnapshot {
    pub files: Vec<bool>,
    pub dirs:  Vec<bool>, // indexed by tree position; non-Dir entries are ignored
}
```

Replace existing `saved_expanded: Vec<bool>` declarations with `saved_expanded: ExpandedSnapshot`. Re-export `ExpandedSnapshot` from `state.rs`.

### Event handler — DirHeader

- [ ] **Step 4.4: Locate the key dispatch and add DirHeader branches**

Run: `grep -n "ListItem::FileHeader" src/tui/app.rs | head -20`

For each location that currently does `match item { ListItem::FileHeader(fi) => ..., ListItem::Entry(...) => ... }`, add a `ListItem::DirHeader(ti) => ...` arm. The required behaviors per spec §6.2:

For the Enter/Space toggle (around `src/tui/app.rs:1113-1121`):

```rust
ListItem::DirHeader(ti) => {
    if let TreeNode::Dir(g) = &mut self.profile.tree[*ti] {
        g.expanded = !g.expanded;
    }
}
```

For the `d` (delete) key handler (search `'d' =>` or similar — the existing key match for `KeyCode::Char('d')`):

```rust
Some(ListItem::DirHeader(ti)) => {
    let (pattern, file_count) = match &self.profile.tree[*ti] {
        TreeNode::Dir(g) => (g.source_pattern.clone(), g.file_indices.len()),
        _ => return Ok(()),
    };
    let confirm = dialoguer::Confirm::new()
        .with_prompt(format!(
            "Remove group '{}' from config? ({} files will be hidden)",
            pattern, file_count
        ))
        .default(false)
        .interact_opt()?
        .unwrap_or(false);
    if confirm {
        if let Some(fc) = self.config.files.get_mut(&self.shell_key) {
            fc.paths.retain(|p| p != &pattern);
        }
        self.config.save()?;
        self.reload_profile()?;
    }
}
```

For the `m` (move) handler — DirHeader is unsupported:

```rust
Some(ListItem::DirHeader(_)) => {
    self.status_line = "Move is not supported on groups".into();
    return Ok(());
}
```

For the `e` / `s` / `x` / `c` / `v` / `r` handlers, add `Some(ListItem::DirHeader(_)) => { return Ok(()); }` no-op arms.

For File-inside-Group `m` blocker — locate the existing `m` for `FileHeader`:

```rust
Some(ListItem::FileHeader(fi)) => {
    let is_inside_group = self.profile.tree.iter().any(|n| matches!(n,
        TreeNode::Dir(g) if g.file_indices.contains(fi)));
    if is_inside_group {
        self.status_line =
            "Files inside a group are sorted alphabetically; move is not supported".into();
        return Ok(());
    }
    // ... existing top-level file move logic
}
```

### Targeted reload helper

- [ ] **Step 4.5: Add `reload_profile()` to `impl TuiApp`**

Insert in `src/tui/app.rs` (anywhere in `impl TuiApp { ... }`):

```rust
/// Spec §6.8 — reload after `a` / `d` / startup_file_check.
///
/// Implementation note (deviation from a fully-surgical patch):
/// we rebuild the profile via load_shell_profile, then **restore dirty
/// in-memory state** for files whose `path` survives the rebuild.
/// Surviving files keep their parsed `entries` (carrying any unsaved
/// edits) and their `dirty: true` flag — so the spec's promise
/// "Dirty files not touched by the patch retain their unsaved edits"
/// is satisfied. Removed-pattern files are dropped (they were going
/// away anyway). Newly-added files come in fresh from disk.
///
/// Clipboard + undo are cleared whenever the file set changes, since
/// they hold file_index references that the rebuild has invalidated.
fn reload_profile(&mut self) -> anyhow::Result<()> {
    use std::collections::HashMap;
    use crate::model::profile::{TreeNode, ProfileFile};

    // Snapshot expanded state.
    let old_file_expanded: HashMap<std::path::PathBuf, bool> = self.profile.files
        .iter().map(|f| (f.path.clone(), f.expanded)).collect();
    let old_dir_expanded: HashMap<String, bool> = self.profile.tree.iter()
        .filter_map(|n| match n {
            TreeNode::Dir(g) => Some((g.source_pattern.clone(), g.expanded)),
            _ => None,
        }).collect();

    // Snapshot old path set + dirty file state.
    // Move dirty files out; the rest is dropped.
    let old_path_set: std::collections::HashSet<std::path::PathBuf> =
        self.profile.files.iter().map(|f| f.path.clone()).collect();
    let mut dirty_snapshot: HashMap<std::path::PathBuf, ProfileFile> = HashMap::new();
    let old_files = std::mem::take(&mut self.profile.files);
    for f in old_files {
        if f.dirty {
            dirty_snapshot.insert(f.path.clone(), f);
        }
    }

    let mut new_profile = crate::model::profile::load_shell_profile(
        &self.config, self.profile.shell_type)?;

    // Restore expanded state by path / pattern key.
    for f in &mut new_profile.files {
        if let Some(&e) = old_file_expanded.get(&f.path) { f.expanded = e; }
    }
    for n in &mut new_profile.tree {
        if let TreeNode::Dir(g) = n {
            if let Some(&e) = old_dir_expanded.get(&g.source_pattern) {
                g.expanded = e;
            }
        }
    }

    // Restore dirty entries for surviving paths. We preserve entries,
    // content, dirty flag; file_index inside Entry is updated to the
    // new ProfileFile position.
    for (new_fi, nf) in new_profile.files.iter_mut().enumerate() {
        if let Some(mut old_pf) = dirty_snapshot.remove(&nf.path) {
            // Reindex Entry.file_index to the new position
            for e in &mut old_pf.entries { e.file_index = new_fi; }
            nf.entries = old_pf.entries;
            nf.content = old_pf.content;
            nf.dirty = true;
            // path / exists / writable / display_label come from the fresh load.
        }
    }

    // Clipboard / undo invalidation: clear whenever the path set changed.
    let new_path_set: std::collections::HashSet<std::path::PathBuf> =
        new_profile.files.iter().map(|f| f.path.clone()).collect();
    if old_path_set != new_path_set {
        self.state.clipboard.clear();
        self.state.undo_stack.clear();
        self.status_line = "Clipboard and undo cleared (file set changed)".into();
    }

    self.profile = new_profile;
    self.visible_items = self.profile.build_visible_list();
    if self.cursor >= self.visible_items.len() {
        self.cursor = self.visible_items.len().saturating_sub(1);
    }
    Ok(())
}
```

Adjust field names (`self.state.clipboard`, `self.state.undo_stack`, `self.status_line`, `self.cursor`, `self.visible_items`) to whatever the actual TuiApp struct uses — read `src/tui/app.rs` definition first:

Run: `sed -n '1,80p' src/tui/app.rs`

### `a` key prompt text

- [ ] **Step 4.6: Update the `a` key prompt**

Search for the existing `a`-key handler in `src/tui/app.rs`. It likely calls `dialoguer::Input::new().with_prompt(...)`. Replace the prompt string with:

```rust
"Add file, group, glob, or $VAR to config"
```

After accepting input, call `self.reload_profile()` instead of any ad-hoc rebuild.

### List rendering

- [ ] **Step 4.7: Read `src/tui/list.rs`**

Run: `cat src/tui/list.rs`

- [ ] **Step 4.8: Update rendering for three-layer indentation**

Identify the function that maps `ListItem` → `ratatui::widgets::ListItem`. Add a `DirHeader` arm and use indent levels:

```rust
ListItem::DirHeader(ti) => {
    let g = match &profile.tree[*ti] {
        TreeNode::Dir(g) => g,
        _ => return None,
    };
    let marker = if g.expanded { "▼" } else { "▶" };
    let line = format!(
        "{} {}    [{} files]",
        marker, g.display_label, g.file_indices.len()
    );
    Some(ratatui::widgets::ListItem::new(line))
}
ListItem::FileHeader(fi) => {
    let f = &profile.files[*fi];
    let marker = if f.expanded { "▼" } else { "▶" };
    // Indent files that live under a DirGroup.
    let inside_group = profile.tree.iter().any(|n| matches!(n,
        TreeNode::Dir(g) if g.file_indices.contains(fi)));
    let prefix = if inside_group { "  " } else { "" };
    let line = format!(
        "{}{} {}    [{} entries]",
        prefix, marker, f.display_name(), f.entry_count()
    );
    Some(ratatui::widgets::ListItem::new(line))
}
ListItem::Entry(fi, ei) => {
    let f = &profile.files[*fi];
    let e = &f.entries[*ei];
    let inside_group = profile.tree.iter().any(|n| matches!(n,
        TreeNode::Dir(g) if g.file_indices.contains(fi)));
    let prefix = if inside_group { "    " } else { "  " };
    let line = format!("{}{}", prefix, e.summary_line()); // existing helper
    Some(ratatui::widgets::ListItem::new(line))
}
```

(`summary_line()` is the existing method that renders an entry — if it's named differently in the current code, keep the existing line-building expression and only change the prefix string.)

### Filter mode

- [ ] **Step 4.9: Update filter logic**

Locate the existing filter handler (around `src/tui/app.rs:1133`). The current code sets `file.expanded = matched_files.contains(&i)` for each file. Add Group handling:

```rust
fn apply_filter(&mut self) {
    let query = self.filter.query.to_lowercase();
    // Determine which files have at least one matching entry.
    let mut matched_files: std::collections::HashSet<usize> =
        std::collections::HashSet::new();
    for (fi, f) in self.profile.files.iter().enumerate() {
        if f.entries.iter().any(|e| e.matches_query(&query)) {
            matched_files.insert(fi);
        }
    }

    // Expand matching files; collapse non-matching.
    for (fi, f) in self.profile.files.iter_mut().enumerate() {
        f.expanded = matched_files.contains(&fi);
    }

    // Expand groups that have at least one matching descendant; collapse others.
    for n in &mut self.profile.tree {
        if let TreeNode::Dir(g) = n {
            g.expanded = g.file_indices.iter().any(|fi| matched_files.contains(fi));
        }
    }

    self.matched_files = matched_files;
    self.visible_items = self.profile.build_visible_list_filtered();
}
```

Then add a sister method on `ShellProfile`:

```rust
// in src/model/profile.rs
impl ShellProfile {
    /// Like build_visible_list but additionally skips non-matching items
    /// based on the provided set. Used in filter mode.
    pub fn build_visible_list_filtered(
        &self,
        matched_files: &std::collections::HashSet<usize>,
    ) -> Vec<ListItem> {
        let mut items = Vec::new();
        for (ti, node) in self.tree.iter().enumerate() {
            match node {
                TreeNode::Dir(g) => {
                    let any_match = g.file_indices.iter()
                        .any(|fi| matched_files.contains(fi));
                    if !any_match { continue; }
                    items.push(ListItem::DirHeader(ti));
                    if g.expanded {
                        for &fi in &g.file_indices {
                            if !matched_files.contains(&fi) { continue; }
                            items.push(ListItem::FileHeader(fi));
                            if self.files[fi].expanded {
                                for ei in 0..self.files[fi].entries.len() {
                                    items.push(ListItem::Entry(fi, ei));
                                }
                            }
                        }
                    }
                }
                TreeNode::File(fi) => {
                    if !matched_files.contains(fi) { continue; }
                    items.push(ListItem::FileHeader(*fi));
                    if self.files[*fi].expanded {
                        for ei in 0..self.files[*fi].entries.len() {
                            items.push(ListItem::Entry(*fi, ei));
                        }
                    }
                }
            }
        }
        items
    }
}
```

Update the `apply_filter` caller signature: `self.profile.build_visible_list_filtered(&matched_files)`.

### Saved expanded restoration

- [ ] **Step 4.10: Capture and restore snapshot on filter Esc**

Locate the filter Esc handler. Before applying filter, save:

```rust
self.state.saved_expanded = ExpandedSnapshot {
    files: self.profile.files.iter().map(|f| f.expanded).collect(),
    dirs:  self.profile.tree.iter().map(|n| match n {
        TreeNode::Dir(g) => g.expanded,
        _ => false,
    }).collect(),
};
```

On Esc (filter exit), restore:

```rust
for (i, f) in self.profile.files.iter_mut().enumerate() {
    if let Some(&e) = self.state.saved_expanded.files.get(i) { f.expanded = e; }
}
for (i, n) in self.profile.tree.iter_mut().enumerate() {
    if let (TreeNode::Dir(g), Some(&e)) = (n, self.state.saved_expanded.dirs.get(i)) {
        g.expanded = e;
    }
}
```

### Build + smoke

- [ ] **Step 4.11: Build and run**

Run: `cargo build --bin wenv`
Expected: clean. Fix any compile errors as they surface (field names, method names).

Run: `cargo test`
Expected: all green.

- [ ] **Step 4.12: Commit**

```bash
git add src/tui/app.rs src/tui/list.rs src/tui/ui.rs src/tui/state.rs src/model/profile.rs tests/targeted_reload.rs
git commit -m "feat(tui): three-layer rendering, DirHeader keys, targeted reload

- DirHeader events: Enter toggles group; d confirms + removes pattern
  from config; m/e/s/x/c/v/r are no-ops with status hints.
- Files inside a group reject m with explanatory status line.
- a prompt: 'Add file, group, glob, or \$VAR to config'.
- Three-level indentation (0/2/4) + [N files] / [N entries] suffixes.
- Filter hides non-matching files inside expanded groups and hides
  groups with zero matching descendants. ExpandedSnapshot covers both
  file and group state on filter activate/exit.
- reload_profile() preserves expanded state by path/pattern key;
  clipboard + undo invalidated when the file set changes.

Spec §6.2, §6.3, §6.4, §6.5, §6.6, §6.8."
```

---


## Files touched

- src/tui/state.rs
- src/tui/app.rs
- src/tui/list.rs
- src/tui/ui.rs
- src/model/profile.rs
- tests/targeted_reload.rs

## Job

Verify spec compliance for Task 4: DirHeader rendering, key bindings, targeted reload, filter behavior, ExpandedSnapshot.

## Severity
`blocker` | `major` | `minor`

## Round Discipline
(Round 1 — focused). Spot-check 3-5 load-bearing claims; grep first.

## Output

```yaml
---
status: PASS | ISSUES_FOUND
issues:
  - severity: blocker | major | minor
    location: "<file:line>"
    description: "<gap>"
    suggestion: "<fix>"
---
```
