# Spec Compliance Review — Task 4 R2 verify-only

- Spec: `/Volumes/Home/Users/wen/repos/wenv/docs/superpowers/specs/2026-05-22-multi-layer-tree-and-config-fallback-design.md`
- Stage: `task 4`
- Round: 2

## Scope Guard
ONLY task 4.

## Round Discipline
**verify-only mode**. Confirm each R1 issue: `resolved | unresolved | partially-resolved`. NEW findings only at `blocker`.

## R1 issues to verify (from spec-compliance R1)

### Issue 1 (MAJOR) — Filter mode group expansion missing
Was at `src/tui/app.rs:1197-1217`. Fix (commit 9ca7596): `rebuild_list` now sets `g.expanded = true` for DirGroups containing matched files.

### Issue 2 (MAJOR) — File-inside-Group guard on StartMove missing
Was at `src/tui/app.rs:514-539`. Fix: Added `is_inside_group` check in StartMove/FileHeader handler; emits "Files inside a group are sorted alphabetically; move is not supported" and returns.

### Issue 3 (MINOR/MAJOR) — Three-level indentation missing
Was at `src/tui/ui.rs:233-274`. Fix: FileHeader inside group gets 2-space indent; Entry inside group gets 4-space indent.

## Output

```yaml
---
status: PASS | ISSUES_FOUND
issues:
  - severity: blocker
    location: "<file:line>"
    description: "<what>"
    suggestion: "<fix>"
---
```
