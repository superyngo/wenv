The fix is complete and verified. Here's the summary:

**R2 Blocker: resolved**

- `ExpandedSnapshot` now has both `files: Vec<bool>` and `dirs: Vec<bool>` fields (`state.rs:68-71`)
- `restore_expanded` takes `&ExpandedSnapshot` and restores both file expanded states and dir group expanded states (`app.rs:1567-1582`)
- All three exit paths use `&ExpandedSnapshot`:
  - No-change path: `restore_expanded(&fms.saved_expanded)` (`app.rs:1464`)
  - Actual-move path: builds new `ExpandedSnapshot` with reordered files but unchanged dirs, then `restore_expanded(&new_expanded)` (`app.rs:1505-1511`)
  - Cancel path: `restore_expanded(&fms.saved_expanded)` (`app.rs:1541`)
- The capture site at `StartMove` (`app.rs:529-534`) correctly captures both file and dir expanded states
- No remaining caller passes `&[bool]`

```yaml
---
status: PASS
issues: []
---
```
