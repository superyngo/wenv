# Spec Compliance Review — Task 4 R3 verify-only

- Spec: `/Volumes/Home/Users/wen/repos/wenv/docs/superpowers/specs/2026-05-22-multi-layer-tree-and-config-fallback-design.md`
- Stage: `task 4`
- Round: 3

## Scope Guard
ONLY task 4.

## Round Discipline
**verify-only mode**. Confirm R2 blocker: `resolved | unresolved | partially-resolved`. NEW findings only at `blocker`.

## R2 issue to verify

### Issue (BLOCKER) — Dir expanded state not restored after file move
Was at `src/tui/app.rs:1464,1508,1538` + `restore_expanded` at `:1564`. `StartMove` captured `ExpandedSnapshot.dirs` but all three file-move exit paths only restored files via `restore_expanded(&[bool])`.

**Fix (commit d0ff045):**
- `restore_expanded` signature changed from `&[bool]` to `&ExpandedSnapshot` (files + dirs)
- Now iterates `profile.tree` restoring `DirGroup.expanded` from `snap.dirs`
- All three exit paths updated: no-change, actual-move (builds new `ExpandedSnapshot` with reordered files but unchanged dirs), cancel.

Verify the fix is complete; no remaining caller still passes `&[bool]`.

## Output

```yaml
---
status: PASS | ISSUES_FOUND
issues:
  - severity: blocker
    location: "<file:line>"
    description: "<what>"
    suggestion: "<fix>"
---
```
